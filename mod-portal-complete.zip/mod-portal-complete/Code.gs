const TABLES = {
  Users: [
    "id","username","passwordHash","passwordSalt","displayName","role","clearance","status","mentorId","forcePasswordReset","description","pronouns","roleTitle","timezone","avatarFileId","bio","askMeAbout","availability","accentColor","onboardingComplete","createdAt","lastLogin"
  ],
  Sessions: [
    "id","userId","tokenHash","createdAt","expiresAt","revoked","lastSeenAt"
  ],
  Content: [
    "key","value","updatedAt","updatedBy"
  ],
  Lessons: [
    "id","order","title","description","published","prerequisiteId","mentorUnlockRequired","passingScore","createdAt","updatedAt","updatedBy"
  ],
  LessonPages: [
    "id","lessonId","order","title","body","createdAt","updatedAt","updatedBy"
  ],
  Quizzes: [
    "id","lessonId","pageId","order","title","kind","passingScore","mentorUnlockRequired","published","createdAt","updatedAt","updatedBy"
  ],
  QuizQuestions: [
    "id","quizId","order","type","prompt","optionsJson","correctAnswer","points","explanation","published","createdAt","updatedAt","updatedBy"
  ],
  TrainingProgress: [
    "userId","lessonId","status","progress","currentPageId","mentorUnlock","finalQuizUnlocked","score","startedAt","completedAt","updatedAt"
  ],
  Notes: [
    "id","userId","lessonId","pageId","body","updatedAt"
  ],
  QuizAttempts: [
    "id","userId","quizId","lessonId","score","passed","status","answersJson","submittedAt","gradedAt","reviewerId","feedback"
  ],
  Grades: [
    "id","userId","lessonId","quizId","title","status","score","reviewerId","feedback","createdAt","updatedAt"
  ],
  Messages: [
    "id","threadId","senderId","recipientId","body","createdAt","readAt"
  ],
  Notifications: [
    "id","userId","title","description","type","read","createdAt"
  ],
  Policies: [
    "id","title","category","description","body","published","requiresAcknowledgement","createdAt","updatedAt","updatedBy"
  ],
  PolicyAcknowledgements: [
    "userId","policyId","acknowledgedAt"
  ],
  Resources: [
    "id","title","category","description","url","status","published","createdBy","approvedBy","createdAt","updatedAt","updatedBy"
  ],
  Onboarding: [
    "id","order","title","description","body","required","published","createdAt","updatedAt","updatedBy"
  ],
  OnboardingProgress: [
    "userId","stepId","completed","completedAt"
  ],
  RestrictedRecords: [
    "id","title","userId","status","description","evidenceJson","extraNotes","createdAt","updatedAt","createdBy","updatedBy"
  ],
  RestrictedAccessLog: [
    "id","recordId","viewerId","action","time"
  ],
  Uploads: [
    "id","driveFileId","ownerId","category","name","mimeType","createdAt"
  ],
  Announcements: [
    "id","title","description","pinned","published","createdAt","createdBy","updatedAt","updatedBy"
  ],
  Audit: [
    "id","time","userId","action","targetType","targetId","details"
  ],
  Settings: [
    "key","value","updatedAt","updatedBy"
  ],
  UserSettings: [
    "userId","theme","density","sidebarCollapsed","reducedMotion","highContrast","portalNotifications","messageNotifications","updatedAt"
  ],
  Help: [
    "id","title","description","body","published","createdAt","updatedAt","updatedBy"
  ]
};

const SESSION_HOURS = 12;
const LOGIN_MAX_FAILURES = 8;
const LOGIN_WINDOW_MINUTES = 15;
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;

const DEFAULT_CONTENT = {
  "dashboard.subtitle": "Your current training, feedback, notices, and portal activity.",
  "training.subtitle": "Open available lessons, save notes, and complete knowledge checks.",
  "grades.subtitle": "Review quiz scores, mentor feedback, and pending grading.",
  "messages.subtitle": "Send direct portal messages to other staff members.",
  "notifications.subtitle": "Portal updates and account notices.",
  "policies.subtitle": "Current staff policies and required acknowledgements.",
  "resources.subtitle": "Shared moderator resources.",
  "staff.subtitle": "Staff profiles and availability.",
  "onboarding.subtitle": "Complete the required onboarding steps for your account.",
  "mentor.subtitle": "Review assigned cadets and control training access.",
  "submissions.subtitle": "Review pending short-answer and quiz submissions.",
  "staff-management.subtitle": "Manage staff status and mentor assignments.",
  "curriculum.subtitle": "Create and edit lessons, lesson pages, quizzes, and questions.",
  "onboarding-management.subtitle": "Create and edit onboarding steps.",
  "restricted.subtitle": "Restricted staff records require password re-entry for each access.",
  "audit.subtitle": "Review recorded portal actions.",
  "accounts.subtitle": "Create accounts, approve requests, reset passwords, and manage clearance.",
  "announcements.subtitle": "Create and publish portal announcements.",
  "portal-content.subtitle": "Edit descriptive portal text shown throughout the site.",
  "admin-tools.subtitle": "Maintenance, session cleanup, backups, and system status.",
  "profile.subtitle": "Edit your staff profile.",
  "settings.subtitle": "Change your personal portal display and notification settings.",
  "help.subtitle": "Portal guidance and help entries."
};

class ApiError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

function setupDatabase() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  if (!spreadsheet) throw new Error("No spreadsheet found.");

  const properties = PropertiesService.getScriptProperties();
  properties.setProperty("SPREADSHEET_ID", spreadsheet.getId());

  if (!properties.getProperty("PASSWORD_PEPPER")) {
    properties.setProperty("PASSWORD_PEPPER", createSecret_());
  }

  if (!properties.getProperty("SESSION_SECRET")) {
    properties.setProperty("SESSION_SECRET", createSecret_());
  }

  Object.entries(TABLES).forEach(([name, headers]) => ensureSheet_(spreadsheet, name, headers));
  syncUserSchema_();
  seedContent_();
  return true;
}

function createMyProfile() {
  setupDatabase();

  const username = "YOUR_USERNAME";
  const password = "YOUR_PASSWORD";
  const displayName = "YOUR_DISPLAY_NAME";

  validateUsername_(username);
  validatePassword_(password);

  if (findUserByUsername_(username)) throw new Error("That username already exists.");

  const now = new Date().toISOString();
  const salt = createSalt_();
  const user = {
    id: Utilities.getUuid(),
    username: String(username).trim(),
    passwordHash: passwordHash_(password, salt),
    passwordSalt: salt,
    displayName: String(displayName).trim() || String(username).trim(),
    role: "Owner",
    clearance: 5,
    status: "active",
    mentorId: "",
    forcePasswordReset: false,
    description: "",
    pronouns: "",
    roleTitle: "",
    timezone: "",
    avatarFileId: "",
    bio: "",
    askMeAbout: "",
    availability: "",
    accentColor: "",
    onboardingComplete: true,
    createdAt: now,
    lastLogin: ""
  };

  appendObject_("Users", user);
  addAudit_(user.id, "account_created", "user", user.id, "Owner account created manually");
  return true;
}

function doGet() {
  return jsonResponse_({ ok: true, service: "mod-portal", status: "online", time: new Date().toISOString() });
}

function doPost(e) {
  try {
    const body = parseBody_(e);
    const action = String(body.action || "").trim();
    if (!action) throw new ApiError("MISSING_ACTION", "No action was provided.");

    let result;

    if (action === "requestAccess") result = requestAccess_(body);
    else if (action === "login") result = login_(body);
    else {
      const auth = requireSession_(body.token);
      result = routeAuthenticated_(action, body, auth);
    }

    return jsonResponse_({ ok: true, ...(result || {}) });
  } catch (error) {
    return jsonResponse_({ ok: false, code: error.code || "SERVER_ERROR", error: error.message || "Request failed." });
  }
}

function routeAuthenticated_(action, body, auth) {
  if (toBoolean_(auth.user.forcePasswordReset) && !["session", "bootstrap", "logout", "logoutAll", "changePassword"].includes(action)) {
    throw new ApiError("PASSWORD_RESET_REQUIRED", "You must change your password before using the portal.");
  }

  switch (action) {
    case "session": return { user: publicUser_(auth.user), expiresAt: auth.session.expiresAt };
    case "bootstrap": return bootstrap_(auth);
    case "logout": return logout_(body, auth);
    case "logoutAll": return logoutAll_(auth);
    case "changePassword": return changePassword_(body, auth);
    case "dashboard": return dashboard_(auth);
    case "getProfile": return getProfile_(body, auth);
    case "updateProfile": return updateProfile_(body, auth);
    case "uploadAvatar": return uploadAvatar_(body, auth);
    case "getAvatar": return getAvatar_(body, auth);
    case "listStaff": return listStaff_(auth);
    case "listLessons": return listLessons_(auth);
    case "getLesson": return getLesson_(body, auth);
    case "startLesson": return startLesson_(body, auth);
    case "completePage": return completePage_(body, auth);
    case "saveNote": return saveNote_(body, auth);
    case "submitQuiz": return submitQuiz_(body, auth);
    case "listGrades": return listGrades_(auth);
    case "listMessages": return listMessages_(auth);
    case "sendMessage": return sendMessage_(body, auth);
    case "markMessageRead": return markMessageRead_(body, auth);
    case "listNotifications": return listNotifications_(auth);
    case "markNotificationRead": return markNotificationRead_(body, auth);
    case "markAllNotificationsRead": return markAllNotificationsRead_(auth);
    case "listPolicies": return listPolicies_(auth);
    case "acknowledgePolicy": return acknowledgePolicy_(body, auth);
    case "savePolicy": return savePolicy_(body, auth);
    case "deletePolicy": return deletePolicy_(body, auth);
    case "listResources": return listResources_(auth);
    case "saveResource": return saveResource_(body, auth);
    case "deleteResource": return deleteResource_(body, auth);
    case "listOnboarding": return listOnboarding_(auth);
    case "completeOnboardingStep": return completeOnboardingStep_(body, auth);
    case "getMentorDashboard": return getMentorDashboard_(auth);
    case "setTrainingAccess": return setTrainingAccess_(body, auth);
    case "listPendingSubmissions": return listPendingSubmissions_(auth);
    case "gradeSubmission": return gradeSubmission_(body, auth);
    case "listAccounts": return listAccounts_(auth);
    case "createAccount": return createAccount_(body, auth);
    case "approveAccount": return approveAccount_(body, auth);
    case "rejectAccount": return rejectAccount_(body, auth);
    case "suspendAccount": return suspendAccount_(body, auth);
    case "reactivateAccount": return reactivateAccount_(body, auth);
    case "assignMentor": return assignMentor_(body, auth);
    case "resetPassword": return resetPassword_(body, auth);
    case "setClearance": return setClearance_(body, auth);
    case "listCurriculum": return listCurriculum_(auth);
    case "saveLesson": return saveLesson_(body, auth);
    case "deleteLesson": return deleteLesson_(body, auth);
    case "saveLessonPage": return saveLessonPage_(body, auth);
    case "deleteLessonPage": return deleteLessonPage_(body, auth);
    case "saveQuiz": return saveQuiz_(body, auth);
    case "deleteQuiz": return deleteQuiz_(body, auth);
    case "saveQuestion": return saveQuestion_(body, auth);
    case "deleteQuestion": return deleteQuestion_(body, auth);
    case "listOnboardingAdmin": return listOnboardingAdmin_(auth);
    case "saveOnboardingStep": return saveOnboardingStep_(body, auth);
    case "deleteOnboardingStep": return deleteOnboardingStep_(body, auth);
    case "listRestricted": return listRestricted_(body, auth);
    case "getRestricted": return getRestricted_(body, auth);
    case "saveRestricted": return saveRestricted_(body, auth);
    case "uploadRestrictedEvidence": return uploadRestrictedEvidence_(body, auth);
    case "getRestrictedEvidence": return getRestrictedEvidence_(body, auth);
    case "listAudit": return listAudit_(auth);
    case "listAnnouncements": return listAnnouncements_(auth);
    case "saveAnnouncement": return saveAnnouncement_(body, auth);
    case "deleteAnnouncement": return deleteAnnouncement_(body, auth);
    case "listHelp": return listHelp_(auth);
    case "saveHelp": return saveHelp_(body, auth);
    case "deleteHelp": return deleteHelp_(body, auth);
    case "getUserSettings": return getUserSettings_(auth);
    case "saveUserSettings": return saveUserSettings_(body, auth);
    case "getContent": return getContent_(auth);
    case "saveContent": return saveContent_(body, auth);
    case "getAdminStats": return getAdminStats_(auth);
    case "setMaintenance": return setMaintenance_(body, auth);
    case "cleanupSessions": return cleanupSessionsAction_(auth);
    case "backupDatabase": return backupDatabase_(auth);
    default: throw new ApiError("UNKNOWN_ACTION", "Unknown action.");
  }
}

function requestAccess_(body) {
  const username = String(body.username || "").trim();
  const displayName = String(body.displayName || "").trim();
  const password = String(body.password || "");

  validateUsername_(username);
  validatePassword_(password);
  if (!displayName) throw new ApiError("DISPLAY_NAME_REQUIRED", "Display name is required.");
  if (findUserByUsername_(username)) throw new ApiError("USERNAME_EXISTS", "That username already exists or has a pending request.");

  return withLock_(() => {
    if (findUserByUsername_(username)) throw new ApiError("USERNAME_EXISTS", "That username already exists or has a pending request.");

    const now = new Date().toISOString();
    const salt = createSalt_();
    const user = {
      id: Utilities.getUuid(),
      username,
      passwordHash: passwordHash_(password, salt),
      passwordSalt: salt,
      displayName,
      role: "Cadet",
      clearance: 1,
      status: "pending",
      mentorId: "",
      forcePasswordReset: false,
      description: "",
      pronouns: "",
      roleTitle: "",
      timezone: "",
      avatarFileId: "",
      bio: "",
      askMeAbout: "",
      availability: "",
      accentColor: "",
      onboardingComplete: false,
      createdAt: now,
      lastLogin: ""
    };

    appendObject_("Users", user);
    notifyClearance_(4, "New account request", `${displayName} requested portal access.`, "account");
    addAudit_(user.id, "access_requested", "user", user.id, username);
    return { status: "pending" };
  });
}

function login_(body) {
  const username = normalizeUsername_(body.username);
  const password = String(body.password || "");

  if (!username || !password) throw new ApiError("INVALID_LOGIN", "Enter your username and password.");
  if (isRateLimited_(username)) throw new ApiError("RATE_LIMITED", "Too many login attempts. Try again later.");

  const user = findUserByUsername_(username);
  const dummySalt = "00000000-0000-0000-0000-000000000000";
  const verification = verifyPassword_(password, user ? String(user.passwordSalt) : dummySalt, user ? String(user.passwordHash || "") : "");

  if (!user || !verification.valid) {
    recordLoginFailure_(username);
    throw new ApiError("INVALID_LOGIN", "Invalid username or password.");
  }

  if (verification.legacy) {
    updateObjectByRow_("Users", user.__row, { passwordHash: verification.currentHash });
    user.passwordHash = verification.currentHash;
  }

  clearLoginFailures_(username);
  const status = String(user.status || "").toLowerCase();

  if (status === "pending") throw new ApiError("ACCOUNT_PENDING", "This account is still waiting for approval.");
  if (status === "suspended") throw new ApiError("ACCOUNT_SUSPENDED", "This account is suspended.");
  if (status !== "active") throw new ApiError("ACCOUNT_INACTIVE", "This account is not active.");

  const maintenance = getSettingValue_("maintenance.enabled", "false") === "true";
  if (maintenance && Number(user.clearance) < 5) throw new ApiError("MAINTENANCE", getSettingValue_("maintenance.message", "The portal is temporarily unavailable."));

  return withLock_(() => {
    cleanupExpiredSessions_();
    const now = new Date().toISOString();
    updateObjectByRow_("Users", user.__row, { lastLogin: now });
    const session = createSession_(user.id);
    addAudit_(user.id, "login", "user", user.id, "");
    return { token: session.token, expiresAt: session.expiresAt, user: publicUser_({ ...user, lastLogin: now }) };
  });
}

function bootstrap_(auth) {
  const announcements = readRows_("Announcements")
    .filter(row => toBoolean_(row.published))
    .sort((a, b) => Number(toBoolean_(b.pinned)) - Number(toBoolean_(a.pinned)) || dateNumber_(b.updatedAt || b.createdAt) - dateNumber_(a.updatedAt || a.createdAt))
    .slice(0, 8)
    .map(cleanRow_);

  const content = {};
  readRows_("Content").forEach(row => content[String(row.key)] = String(row.value || ""));
  const settings = getUserSettingsRow_(auth.user.id);

  return {
    user: publicUser_(auth.user),
    expiresAt: auth.session.expiresAt,
    content,
    announcements,
    settings: cleanRow_(settings),
    maintenance: {
      enabled: getSettingValue_("maintenance.enabled", "false") === "true",
      message: getSettingValue_("maintenance.message", "")
    }
  };
}

function logout_(body, auth) {
  updateObjectByRow_("Sessions", auth.session.__row, { revoked: true, lastSeenAt: new Date().toISOString() });
  addAudit_(auth.user.id, "logout", "session", auth.session.id, "");
  return {};
}

function logoutAll_(auth) {
  revokeUserSessions_(auth.user.id);
  addAudit_(auth.user.id, "logout_all", "user", auth.user.id, "");
  return {};
}

function changePassword_(body, auth) {
  const currentPassword = String(body.currentPassword || "");
  const newPassword = String(body.newPassword || "");
  validatePassword_(newPassword);

  const user = findUserById_(auth.user.id);
  if (!user) throw new ApiError("USER_NOT_FOUND", "Account not found.");

  const verification = verifyPassword_(currentPassword, String(user.passwordSalt), String(user.passwordHash));
  if (!verification.valid) throw new ApiError("INVALID_PASSWORD", "Current password is incorrect.");

  return withLock_(() => {
    const salt = createSalt_();
    updateObjectByRow_("Users", user.__row, {
      passwordSalt: salt,
      passwordHash: passwordHash_(newPassword, salt),
      forcePasswordReset: false
    });
    revokeUserSessions_(user.id);
    const session = createSession_(user.id);
    addAudit_(user.id, "password_changed", "user", user.id, "");
    return { token: session.token, expiresAt: session.expiresAt, user: publicUser_(findUserById_(user.id)) };
  });
}

function dashboard_(auth) {
  const lessons = listLessonsForUser_(auth.user);
  const grades = listGradesForUser_(auth.user.id).slice(0, 5);
  const notifications = readRows_("Notifications").filter(row => String(row.userId) === String(auth.user.id));
  const messages = readRows_("Messages").filter(row => String(row.recipientId) === String(auth.user.id) || String(row.senderId) === String(auth.user.id));
  const progressRows = readRows_("TrainingProgress").filter(row => String(row.userId) === String(auth.user.id));
  const completed = progressRows.filter(row => String(row.status) === "completed").length;
  const publishedLessons = lessons.filter(row => toBoolean_(row.published));
  const currentLesson = lessons.find(row => row.access.allowed && row.progress.status !== "completed") || null;

  return {
    stats: {
      completedLessons: completed,
      totalLessons: publishedLessons.length,
      unreadNotifications: notifications.filter(row => !toBoolean_(row.read)).length,
      unreadMessages: messages.filter(row => String(row.recipientId) === String(auth.user.id) && !row.readAt).length
    },
    currentLesson,
    recentGrades: grades,
    recentActivity: readRows_("Audit").filter(row => String(row.userId) === String(auth.user.id)).sort((a, b) => dateNumber_(b.time) - dateNumber_(a.time)).slice(0, 8).map(cleanRow_)
  };
}

function getProfile_(body, auth) {
  const targetId = String(body.userId || auth.user.id);
  const user = findUserById_(targetId);
  if (!user) throw new ApiError("USER_NOT_FOUND", "Account not found.");

  if (targetId !== String(auth.user.id) && String(user.status) !== "active") requireClearance_(auth, 4);
  return { profile: profileUser_(user) };
}

function updateProfile_(body, auth) {
  const user = findUserById_(auth.user.id);
  const changes = {
    displayName: limitText_(body.displayName, 80),
    description: limitText_(body.description, 240),
    pronouns: limitText_(body.pronouns, 80),
    roleTitle: limitText_(body.roleTitle, 100),
    timezone: limitText_(body.timezone, 100),
    bio: limitText_(body.bio, 2500),
    askMeAbout: limitText_(body.askMeAbout, 500),
    availability: limitText_(body.availability, 500),
    accentColor: limitText_(body.accentColor, 30)
  };

  if (!changes.displayName) throw new ApiError("DISPLAY_NAME_REQUIRED", "Display name is required.");
  updateObjectByRow_("Users", user.__row, changes);
  addAudit_(auth.user.id, "profile_updated", "user", auth.user.id, "");
  return { profile: profileUser_(findUserById_(auth.user.id)) };
}

function uploadAvatar_(body, auth) {
  const upload = saveUpload_(body, auth.user.id, "avatar");
  const user = findUserById_(auth.user.id);
  updateObjectByRow_("Users", user.__row, { avatarFileId: upload.id });
  addAudit_(auth.user.id, "avatar_updated", "user", auth.user.id, upload.name);
  return { upload: cleanRow_(upload) };
}

function getAvatar_(body, auth) {
  const targetId = String(body.userId || auth.user.id);
  const user = findUserById_(targetId);
  if (!user || !user.avatarFileId) return { dataUrl: "" };
  const upload = findRow_("Uploads", row => String(row.id) === String(user.avatarFileId) && String(row.category) === "avatar");
  if (!upload) return { dataUrl: "" };
  return { dataUrl: uploadDataUrl_(upload) };
}

function listStaff_(auth) {
  const staff = readRows_("Users")
    .filter(row => String(row.status) === "active")
    .sort((a, b) => Number(b.clearance) - Number(a.clearance) || dateNumber_(a.createdAt) - dateNumber_(b.createdAt))
    .map(profileUser_);
  return { staff };
}

function listLessons_(auth) {
  return { lessons: listLessonsForUser_(auth.user) };
}

function listLessonsForUser_(user) {
  const lessons = readRows_("Lessons")
    .filter(row => Number(user.clearance) >= 4 || toBoolean_(row.published))
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));

  const progress = readRows_("TrainingProgress").filter(row => String(row.userId) === String(user.id));
  const byLesson = {};
  progress.forEach(row => byLesson[String(row.lessonId)] = row);

  return lessons.map(lesson => {
    const row = byLesson[String(lesson.id)] || defaultProgress_(user.id, lesson.id);
    return {
      ...cleanRow_(lesson),
      progress: cleanRow_(row),
      access: lessonAccess_(user, lesson, byLesson)
    };
  });
}

function getLesson_(body, auth) {
  const lessonId = requireId_(body.lessonId, "Lesson");
  const lesson = findRow_("Lessons", row => String(row.id) === lessonId);
  if (!lesson) throw new ApiError("LESSON_NOT_FOUND", "Lesson not found.");

  const progressRows = readRows_("TrainingProgress").filter(row => String(row.userId) === String(auth.user.id));
  const byLesson = {};
  progressRows.forEach(row => byLesson[String(row.lessonId)] = row);
  const access = lessonAccess_(auth.user, lesson, byLesson);

  if (Number(auth.user.clearance) < 4 && (!toBoolean_(lesson.published) || !access.allowed)) throw new ApiError("LESSON_LOCKED", access.reason || "This lesson is locked.");

  const pages = readRows_("LessonPages")
    .filter(row => String(row.lessonId) === lessonId)
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0))
    .map(cleanRow_);

  const quizzes = readRows_("Quizzes")
    .filter(row => String(row.lessonId) === lessonId && (Number(auth.user.clearance) >= 4 || toBoolean_(row.published)))
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0))
    .map(quiz => {
      const questions = readRows_("QuizQuestions")
        .filter(row => String(row.quizId) === String(quiz.id) && (Number(auth.user.clearance) >= 4 || toBoolean_(row.published)))
        .sort((a, b) => Number(a.order || 0) - Number(b.order || 0))
        .map(questionPublic_);
      const progress = byLesson[lessonId] || defaultProgress_(auth.user.id, lessonId);
      const unlocked = Number(auth.user.clearance) >= 4 || !toBoolean_(quiz.mentorUnlockRequired) || toBoolean_(progress.finalQuizUnlocked);
      return { ...cleanRow_(quiz), unlocked, questions };
    });

  const notes = readRows_("Notes").filter(row => String(row.userId) === String(auth.user.id) && String(row.lessonId) === lessonId).map(cleanRow_);
  const progress = byLesson[lessonId] || defaultProgress_(auth.user.id, lessonId);

  return { lesson: cleanRow_(lesson), pages, quizzes, notes, progress: cleanRow_(progress), access };
}

function startLesson_(body, auth) {
  const lessonId = requireId_(body.lessonId, "Lesson");
  const lesson = findRow_("Lessons", row => String(row.id) === lessonId);
  if (!lesson) throw new ApiError("LESSON_NOT_FOUND", "Lesson not found.");

  const allProgress = readRows_("TrainingProgress").filter(row => String(row.userId) === String(auth.user.id));
  const byLesson = {};
  allProgress.forEach(row => byLesson[String(row.lessonId)] = row);
  const access = lessonAccess_(auth.user, lesson, byLesson);
  if (Number(auth.user.clearance) < 4 && !access.allowed) throw new ApiError("LESSON_LOCKED", access.reason || "This lesson is locked.");

  const progress = upsertProgress_(auth.user.id, lessonId, {
    status: "in_progress",
    startedAt: existingOrNow_(byLesson[lessonId]?.startedAt),
    updatedAt: new Date().toISOString()
  });

  addAudit_(auth.user.id, "lesson_started", "lesson", lessonId, "");
  return { progress: cleanRow_(progress) };
}

function completePage_(body, auth) {
  const lessonId = requireId_(body.lessonId, "Lesson");
  const pageId = requireId_(body.pageId, "Page");
  const pages = readRows_("LessonPages").filter(row => String(row.lessonId) === lessonId).sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
  const index = pages.findIndex(row => String(row.id) === pageId);
  if (index === -1) throw new ApiError("PAGE_NOT_FOUND", "Lesson page not found.");

  const percent = pages.length ? Math.round(((index + 1) / pages.length) * 100) : 0;
  const progress = upsertProgress_(auth.user.id, lessonId, {
    status: "in_progress",
    progress: percent,
    currentPageId: pageId,
    startedAt: existingOrNow_(findProgress_(auth.user.id, lessonId)?.startedAt),
    updatedAt: new Date().toISOString()
  });
  return { progress: cleanRow_(progress) };
}

function saveNote_(body, auth) {
  const lessonId = requireId_(body.lessonId, "Lesson");
  const pageId = String(body.pageId || "");
  const noteBody = limitText_(body.body, 10000);
  let note = findRow_("Notes", row => String(row.userId) === String(auth.user.id) && String(row.lessonId) === lessonId && String(row.pageId || "") === pageId);
  const now = new Date().toISOString();

  if (note) {
    updateObjectByRow_("Notes", note.__row, { body: noteBody, updatedAt: now });
    note = findRow_("Notes", row => String(row.id) === String(note.id));
  } else {
    note = { id: Utilities.getUuid(), userId: auth.user.id, lessonId, pageId, body: noteBody, updatedAt: now };
    appendObject_("Notes", note);
  }

  return { note: cleanRow_(note) };
}

function submitQuiz_(body, auth) {
  const quizId = requireId_(body.quizId, "Quiz");
  const quiz = findRow_("Quizzes", row => String(row.id) === quizId);
  if (!quiz || (!toBoolean_(quiz.published) && Number(auth.user.clearance) < 4)) throw new ApiError("QUIZ_NOT_FOUND", "Quiz not found.");

  const progress = findProgress_(auth.user.id, quiz.lessonId) || defaultProgress_(auth.user.id, quiz.lessonId);
  if (Number(auth.user.clearance) < 4 && toBoolean_(quiz.mentorUnlockRequired) && !toBoolean_(progress.finalQuizUnlocked)) throw new ApiError("QUIZ_LOCKED", "This quiz must be unlocked by a mentor.");

  const questions = readRows_("QuizQuestions")
    .filter(row => String(row.quizId) === quizId && toBoolean_(row.published))
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));

  if (!questions.length) throw new ApiError("EMPTY_QUIZ", "This quiz has no published questions.");

  const submitted = Array.isArray(body.answers) ? body.answers : [];
  const answerMap = {};
  submitted.forEach(answer => answerMap[String(answer.questionId)] = String(answer.answer ?? ""));

  let earned = 0;
  let possible = 0;
  let hasShortAnswer = false;
  const storedAnswers = [];

  questions.forEach(question => {
    const points = Math.max(1, Number(question.points || 1));
    possible += points;
    const answer = String(answerMap[String(question.id)] || "").trim();
    const type = String(question.type || "multiple_choice");

    if (type === "short_answer") {
      hasShortAnswer = true;
      storedAnswers.push({ questionId: question.id, answer, type, points });
    } else {
      const correct = normalizeAnswer_(question.correctAnswer);
      const isCorrect = normalizeAnswer_(answer) === correct;
      if (isCorrect) earned += points;
      storedAnswers.push({ questionId: question.id, answer, type, points, autoCorrect: isCorrect });
    }
  });

  const score = possible ? Math.round((earned / possible) * 100) : 0;
  const passingScore = Number(quiz.passingScore || 80);
  const status = hasShortAnswer ? "pending" : "graded";
  const passed = !hasShortAnswer && score >= passingScore;
  const now = new Date().toISOString();
  const attempt = {
    id: Utilities.getUuid(),
    userId: auth.user.id,
    quizId,
    lessonId: quiz.lessonId,
    score,
    passed,
    status,
    answersJson: JSON.stringify(storedAnswers),
    submittedAt: now,
    gradedAt: hasShortAnswer ? "" : now,
    reviewerId: "",
    feedback: ""
  };

  appendObject_("QuizAttempts", attempt);
  upsertGrade_(attempt, quiz.title);

  if (!hasShortAnswer && String(quiz.kind) === "final" && passed) completeLesson_(auth.user.id, quiz.lessonId, score);
  if (hasShortAnswer) notifyMentorForSubmission_(auth.user, attempt, quiz);

  addAudit_(auth.user.id, "quiz_submitted", "quiz", quizId, `${status}:${score}`);
  return { attempt: cleanRow_(attempt) };
}

function listGrades_(auth) {
  return { grades: listGradesForUser_(auth.user.id) };
}

function listGradesForUser_(userId) {
  return readRows_("Grades")
    .filter(row => String(row.userId) === String(userId))
    .sort((a, b) => dateNumber_(b.updatedAt || b.createdAt) - dateNumber_(a.updatedAt || a.createdAt))
    .map(row => {
      const reviewer = row.reviewerId ? findUserById_(row.reviewerId) : null;
      return { ...cleanRow_(row), reviewerName: reviewer ? reviewer.displayName : "" };
    });
}

function listMessages_(auth) {
  const users = userNameMap_();
  const messages = readRows_("Messages")
    .filter(row => String(row.senderId) === String(auth.user.id) || String(row.recipientId) === String(auth.user.id))
    .sort((a, b) => dateNumber_(b.createdAt) - dateNumber_(a.createdAt))
    .slice(0, 250)
    .map(row => ({ ...cleanRow_(row), senderName: users[String(row.senderId)] || "Unknown", recipientName: users[String(row.recipientId)] || "Unknown" }));
  return { messages };
}

function sendMessage_(body, auth) {
  const recipientId = requireId_(body.recipientId, "Recipient");
  const recipient = findUserById_(recipientId);
  if (!recipient || String(recipient.status) !== "active") throw new ApiError("RECIPIENT_NOT_FOUND", "Recipient not found.");

  const messageBody = limitText_(body.body, 6000);
  if (!messageBody) throw new ApiError("MESSAGE_REQUIRED", "Message cannot be empty.");

  const threadId = [String(auth.user.id), recipientId].sort().join(":");
  const message = { id: Utilities.getUuid(), threadId, senderId: auth.user.id, recipientId, body: messageBody, createdAt: new Date().toISOString(), readAt: "" };
  appendObject_("Messages", message);
  addNotification_(recipientId, `Message from ${auth.user.displayName}`, messageBody.slice(0, 180), "message");
  addAudit_(auth.user.id, "message_sent", "user", recipientId, "");
  return { message: cleanRow_(message) };
}

function markMessageRead_(body, auth) {
  const id = requireId_(body.id, "Message");
  const message = findRow_("Messages", row => String(row.id) === id);
  if (!message || String(message.recipientId) !== String(auth.user.id)) throw new ApiError("MESSAGE_NOT_FOUND", "Message not found.");
  if (!message.readAt) updateObjectByRow_("Messages", message.__row, { readAt: new Date().toISOString() });
  return {};
}

function listNotifications_(auth) {
  const notifications = readRows_("Notifications")
    .filter(row => String(row.userId) === String(auth.user.id))
    .sort((a, b) => dateNumber_(b.createdAt) - dateNumber_(a.createdAt))
    .slice(0, 250)
    .map(cleanRow_);
  return { notifications };
}

function markNotificationRead_(body, auth) {
  const id = requireId_(body.id, "Notification");
  const row = findRow_("Notifications", item => String(item.id) === id && String(item.userId) === String(auth.user.id));
  if (!row) throw new ApiError("NOTIFICATION_NOT_FOUND", "Notification not found.");
  updateObjectByRow_("Notifications", row.__row, { read: true });
  return {};
}

function markAllNotificationsRead_(auth) {
  readRows_("Notifications").filter(row => String(row.userId) === String(auth.user.id) && !toBoolean_(row.read)).forEach(row => updateObjectByRow_("Notifications", row.__row, { read: true }));
  return {};
}

function listPolicies_(auth) {
  const acknowledgements = readRows_("PolicyAcknowledgements").filter(row => String(row.userId) === String(auth.user.id));
  const ackSet = new Set(acknowledgements.map(row => String(row.policyId)));
  const policies = readRows_("Policies")
    .filter(row => Number(auth.user.clearance) >= 4 || toBoolean_(row.published))
    .sort((a, b) => String(a.category).localeCompare(String(b.category)) || String(a.title).localeCompare(String(b.title)))
    .map(row => ({ ...cleanRow_(row), acknowledged: ackSet.has(String(row.id)) }));
  return { policies };
}

function acknowledgePolicy_(body, auth) {
  const policyId = requireId_(body.policyId, "Policy");
  const policy = findRow_("Policies", row => String(row.id) === policyId && toBoolean_(row.published));
  if (!policy) throw new ApiError("POLICY_NOT_FOUND", "Policy not found.");

  const existing = findRow_("PolicyAcknowledgements", row => String(row.userId) === String(auth.user.id) && String(row.policyId) === policyId);
  if (!existing) appendObject_("PolicyAcknowledgements", { userId: auth.user.id, policyId, acknowledgedAt: new Date().toISOString() });
  addAudit_(auth.user.id, "policy_acknowledged", "policy", policyId, "");
  return {};
}

function savePolicy_(body, auth) {
  requireClearance_(auth, 4);
  const id = String(body.id || "");
  const existing = id ? findRow_("Policies", row => String(row.id) === id) : null;
  const now = new Date().toISOString();
  const changes = {
    title: requiredText_(body.title, "Title", 180),
    category: limitText_(body.category, 120),
    description: limitText_(body.description, 1600),
    body: limitText_(body.body, 30000),
    published: toBoolean_(body.published),
    requiresAcknowledgement: toBoolean_(body.requiresAcknowledgement),
    updatedAt: now,
    updatedBy: auth.user.id
  };
  let row;

  if (existing) {
    updateObjectByRow_("Policies", existing.__row, changes);
    row = findRow_("Policies", item => String(item.id) === id);
  } else {
    row = { id: Utilities.getUuid(), ...changes, createdAt: now };
    appendObject_("Policies", row);
  }

  addAudit_(auth.user.id, existing ? "policy_updated" : "policy_created", "policy", row.id, row.title);
  return { policy: cleanRow_(row) };
}

function deletePolicy_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Policy");
  deleteRowsWhere_("PolicyAcknowledgements", row => String(row.policyId) === id);
  deleteRowById_("Policies", id);
  addAudit_(auth.user.id, "policy_deleted", "policy", id, "");
  return {};
}

function listResources_(auth) {
  const rows = readRows_("Resources")
    .filter(row => Number(auth.user.clearance) >= 4 || (toBoolean_(row.published) && String(row.status) === "approved"))
    .sort((a, b) => dateNumber_(b.updatedAt || b.createdAt) - dateNumber_(a.updatedAt || a.createdAt))
    .map(cleanRow_);
  return { resources: rows };
}

function saveResource_(body, auth) {
  requireClearance_(auth, 4);
  const id = String(body.id || "");
  const existing = id ? findRow_("Resources", row => String(row.id) === id) : null;
  const now = new Date().toISOString();
  const isOwner = Number(auth.user.clearance) >= 5;
  const changes = {
    title: requiredText_(body.title, "Title", 180),
    category: limitText_(body.category, 120),
    description: limitText_(body.description, 1200),
    url: limitText_(body.url, 1500),
    status: isOwner ? (toBoolean_(body.published) ? "approved" : "draft") : "pending",
    published: isOwner ? toBoolean_(body.published) : false,
    approvedBy: isOwner && toBoolean_(body.published) ? auth.user.id : "",
    updatedAt: now,
    updatedBy: auth.user.id
  };

  let resource;
  if (existing) {
    updateObjectByRow_("Resources", existing.__row, changes);
    resource = findRow_("Resources", row => String(row.id) === id);
  } else {
    resource = { id: Utilities.getUuid(), ...changes, createdBy: auth.user.id, createdAt: now };
    appendObject_("Resources", resource);
  }

  if (!isOwner) notifyClearance_(5, "Resource awaiting approval", `${auth.user.displayName} submitted ${resource.title}.`, "resource");
  addAudit_(auth.user.id, existing ? "resource_updated" : "resource_created", "resource", resource.id, resource.title);
  return { resource: cleanRow_(resource) };
}

function deleteResource_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Resource");
  deleteRowById_("Resources", id);
  addAudit_(auth.user.id, "resource_deleted", "resource", id, "");
  return {};
}

function listOnboarding_(auth) {
  const progress = readRows_("OnboardingProgress").filter(row => String(row.userId) === String(auth.user.id));
  const done = new Set(progress.filter(row => toBoolean_(row.completed)).map(row => String(row.stepId)));
  const steps = readRows_("Onboarding")
    .filter(row => toBoolean_(row.published))
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0))
    .map(row => ({ ...cleanRow_(row), completed: done.has(String(row.id)) }));
  return { steps, onboardingComplete: toBoolean_(auth.user.onboardingComplete) };
}

function completeOnboardingStep_(body, auth) {
  const stepId = requireId_(body.stepId, "Onboarding step");
  const step = findRow_("Onboarding", row => String(row.id) === stepId && toBoolean_(row.published));
  if (!step) throw new ApiError("STEP_NOT_FOUND", "Onboarding step not found.");

  let progress = findRow_("OnboardingProgress", row => String(row.userId) === String(auth.user.id) && String(row.stepId) === stepId);
  const now = new Date().toISOString();
  if (progress) updateObjectByRow_("OnboardingProgress", progress.__row, { completed: true, completedAt: now });
  else appendObject_("OnboardingProgress", { userId: auth.user.id, stepId, completed: true, completedAt: now });

  updateOnboardingCompletion_(auth.user.id);
  addAudit_(auth.user.id, "onboarding_step_completed", "onboarding", stepId, "");
  return { onboardingComplete: toBoolean_(findUserById_(auth.user.id).onboardingComplete) };
}

function getMentorDashboard_(auth) {
  requireClearance_(auth, 2);
  const cadets = mentorCadets_(auth);
  const lessons = readRows_("Lessons").sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
  const progress = readRows_("TrainingProgress");

  return {
    cadets: cadets.map(cadet => ({
      ...profileUser_(cadet),
      progress: lessons.map(lesson => {
        const row = progress.find(item => String(item.userId) === String(cadet.id) && String(item.lessonId) === String(lesson.id)) || defaultProgress_(cadet.id, lesson.id);
        return { lessonId: lesson.id, lessonTitle: lesson.title, ...cleanRow_(row) };
      })
    }))
  };
}

function setTrainingAccess_(body, auth) {
  requireClearance_(auth, 2);
  const userId = requireId_(body.userId, "Cadet");
  const lessonId = requireId_(body.lessonId, "Lesson");
  assertMentorControlsUser_(auth, userId);
  const cadet = findUserById_(userId);
  if (!cadet || Number(cadet.clearance) !== 1) throw new ApiError("CADET_NOT_FOUND", "Cadet not found.");

  const changes = { updatedAt: new Date().toISOString() };
  if (body.mentorUnlock !== undefined) changes.mentorUnlock = toBoolean_(body.mentorUnlock);
  if (body.finalQuizUnlocked !== undefined) changes.finalQuizUnlocked = toBoolean_(body.finalQuizUnlocked);
  const progress = upsertProgress_(userId, lessonId, changes);
  addNotification_(userId, "Training access updated", "Your mentor updated your lesson or final quiz access.", "training");
  addAudit_(auth.user.id, "training_access_updated", "user", userId, lessonId);
  return { progress: cleanRow_(progress) };
}

function listPendingSubmissions_(auth) {
  requireClearance_(auth, 2);
  const allowedUsers = new Set(mentorCadets_(auth).map(row => String(row.id)));
  const attempts = readRows_("QuizAttempts")
    .filter(row => String(row.status) === "pending" && (Number(auth.user.clearance) >= 4 || allowedUsers.has(String(row.userId))))
    .sort((a, b) => dateNumber_(a.submittedAt) - dateNumber_(b.submittedAt))
    .map(attemptDetail_);
  return { submissions: attempts };
}

function gradeSubmission_(body, auth) {
  requireClearance_(auth, 2);
  const attemptId = requireId_(body.attemptId, "Submission");
  const attempt = findRow_("QuizAttempts", row => String(row.id) === attemptId);
  if (!attempt) throw new ApiError("SUBMISSION_NOT_FOUND", "Submission not found.");
  assertMentorControlsUser_(auth, attempt.userId);

  const quiz = findRow_("Quizzes", row => String(row.id) === String(attempt.quizId));
  if (!quiz) throw new ApiError("QUIZ_NOT_FOUND", "Quiz not found.");

  const score = clampNumber_(body.score, 0, 100);
  const feedback = limitText_(body.feedback, 5000);
  const passed = score >= Number(quiz.passingScore || 80);
  const now = new Date().toISOString();

  updateObjectByRow_("QuizAttempts", attempt.__row, { score, passed, status: "graded", gradedAt: now, reviewerId: auth.user.id, feedback });
  const updated = findRow_("QuizAttempts", row => String(row.id) === attemptId);
  upsertGrade_(updated, quiz.title);
  if (String(quiz.kind) === "final" && passed) completeLesson_(attempt.userId, quiz.lessonId, score);

  addNotification_(attempt.userId, "Submission graded", `${quiz.title} was graded. Score: ${score}%.`, "grade");
  addAudit_(auth.user.id, "submission_graded", "quiz_attempt", attemptId, String(score));
  return { submission: attemptDetail_(updated) };
}

function listAccounts_(auth) {
  requireClearance_(auth, 4);
  const accounts = readRows_("Users")
    .sort((a, b) => Number(b.clearance) - Number(a.clearance) || dateNumber_(a.createdAt) - dateNumber_(b.createdAt))
    .map(adminUser_);
  return { accounts };
}

function createAccount_(body, auth) {
  requireClearance_(auth, 4);
  const username = String(body.username || "").trim();
  const displayName = requiredText_(body.displayName, "Display name", 80);
  const password = String(body.password || "");
  const requestedClearance = clampNumber_(body.clearance || 1, 1, 5);
  const clearance = Number(auth.user.clearance) >= 5 ? requestedClearance : Math.min(requestedClearance, 3);

  validateUsername_(username);
  validatePassword_(password);
  if (findUserByUsername_(username)) throw new ApiError("USERNAME_EXISTS", "That username already exists.");

  const now = new Date().toISOString();
  const salt = createSalt_();
  const user = {
    id: Utilities.getUuid(), username, passwordHash: passwordHash_(password, salt), passwordSalt: salt,
    displayName, role: roleForClearance_(clearance), clearance, status: "active", mentorId: "",
    forcePasswordReset: toBoolean_(body.forcePasswordReset), description: "", pronouns: "", roleTitle: "", timezone: "",
    avatarFileId: "", bio: "", askMeAbout: "", availability: "", accentColor: "", onboardingComplete: clearance > 1,
    createdAt: now, lastLogin: ""
  };
  appendObject_("Users", user);
  addNotification_(user.id, "Account created", "Your portal account has been activated.", "account");
  addAudit_(auth.user.id, "account_created", "user", user.id, username);
  return { account: adminUser_(user) };
}

function approveAccount_(body, auth) {
  requireClearance_(auth, 4);
  const user = findUserTarget_(body);
  if (!user) throw new ApiError("USER_NOT_FOUND", "Account not found.");
  if (String(user.status) !== "pending") throw new ApiError("NOT_PENDING", "That account is not pending approval.");

  const requested = clampNumber_(body.clearance || 1, 1, 5);
  const clearance = Number(auth.user.clearance) >= 5 ? requested : Math.min(requested, 3);
  updateObjectByRow_("Users", user.__row, { status: "active", clearance, role: roleForClearance_(clearance), onboardingComplete: clearance > 1 });
  addNotification_(user.id, "Account approved", "Your portal account has been approved.", "account");
  addAudit_(auth.user.id, "account_approved", "user", user.id, String(clearance));
  return { account: adminUser_(findUserById_(user.id)) };
}

function rejectAccount_(body, auth) {
  requireClearance_(auth, 4);
  const user = findUserTarget_(body);
  if (!user) throw new ApiError("USER_NOT_FOUND", "Account not found.");
  if (String(user.status) !== "pending") throw new ApiError("NOT_PENDING", "That account is not pending approval.");

  updateObjectByRow_("Users", user.__row, { status: "rejected" });
  revokeUserSessions_(user.id);
  addAudit_(auth.user.id, "account_rejected", "user", user.id, limitText_(body.reason, 1000));
  return { account: adminUser_(findUserById_(user.id)) };
}

function suspendAccount_(body, auth) {
  requireClearance_(auth, 4);
  const user = findUserTarget_(body);
  if (!user) throw new ApiError("USER_NOT_FOUND", "Account not found.");
  if (String(user.id) === String(auth.user.id)) throw new ApiError("SELF_ACTION_BLOCKED", "You cannot suspend your own account.");
  if (Number(user.clearance) >= 5 && Number(auth.user.clearance) < 5) throw new ApiError("FORBIDDEN", "Only an owner can suspend an owner account.");

  updateObjectByRow_("Users", user.__row, { status: "suspended" });
  revokeUserSessions_(user.id);
  addAudit_(auth.user.id, "account_suspended", "user", user.id, limitText_(body.reason, 1000));
  return { account: adminUser_(findUserById_(user.id)) };
}

function reactivateAccount_(body, auth) {
  requireClearance_(auth, 4);
  const user = findUserTarget_(body);
  if (!user) throw new ApiError("USER_NOT_FOUND", "Account not found.");
  updateObjectByRow_("Users", user.__row, { status: "active" });
  addNotification_(user.id, "Account reactivated", "Your portal account is active again.", "account");
  addAudit_(auth.user.id, "account_reactivated", "user", user.id, "");
  return { account: adminUser_(findUserById_(user.id)) };
}

function assignMentor_(body, auth) {
  requireClearance_(auth, 4);
  const cadetId = requireId_(body.userId, "Cadet");
  const mentorId = String(body.mentorId || "");
  const cadet = findUserById_(cadetId);
  if (!cadet || Number(cadet.clearance) !== 1) throw new ApiError("CADET_NOT_FOUND", "Cadet not found.");

  if (mentorId) {
    const mentor = findUserById_(mentorId);
    if (!mentor || Number(mentor.clearance) < 2 || String(mentor.status) !== "active") throw new ApiError("MENTOR_NOT_FOUND", "Mentor not found.");
  }

  updateObjectByRow_("Users", cadet.__row, { mentorId });
  addNotification_(cadet.id, "Mentor assignment updated", mentorId ? "Your mentor assignment was updated." : "Your mentor assignment was cleared.", "account");
  addAudit_(auth.user.id, "mentor_assigned", "user", cadet.id, mentorId);
  return { account: adminUser_(findUserById_(cadet.id)) };
}

function resetPassword_(body, auth) {
  requireClearance_(auth, 4);
  const user = findUserTarget_(body);
  if (!user) throw new ApiError("USER_NOT_FOUND", "Account not found.");
  if (Number(user.clearance) >= 5 && Number(auth.user.clearance) < 5) throw new ApiError("FORBIDDEN", "Only an owner can reset an owner password.");

  const temporaryPassword = generateTemporaryPassword_();
  const salt = createSalt_();
  updateObjectByRow_("Users", user.__row, { passwordSalt: salt, passwordHash: passwordHash_(temporaryPassword, salt), forcePasswordReset: true });
  revokeUserSessions_(user.id);
  addAudit_(auth.user.id, "password_reset", "user", user.id, "");
  return { temporaryPassword };
}

function setClearance_(body, auth) {
  requireClearance_(auth, 5);
  const user = findUserTarget_(body);
  if (!user) throw new ApiError("USER_NOT_FOUND", "Account not found.");
  if (String(user.id) === String(auth.user.id)) throw new ApiError("SELF_ACTION_BLOCKED", "You cannot change your own clearance from this panel.");

  const clearance = clampNumber_(body.clearance, 1, 5);
  updateObjectByRow_("Users", user.__row, { clearance, role: roleForClearance_(clearance), mentorId: clearance === 1 ? user.mentorId : "" });
  addNotification_(user.id, "Clearance updated", `Your clearance is now ${clearance}.`, "account");
  addAudit_(auth.user.id, "clearance_updated", "user", user.id, String(clearance));
  return { account: adminUser_(findUserById_(user.id)) };
}

function listCurriculum_(auth) {
  requireClearance_(auth, 4);
  return {
    lessons: readRows_("Lessons").sort(orderSort_).map(cleanRow_),
    pages: readRows_("LessonPages").sort(orderSort_).map(cleanRow_),
    quizzes: readRows_("Quizzes").sort(orderSort_).map(cleanRow_),
    questions: readRows_("QuizQuestions").sort(orderSort_).map(row => ({ ...cleanRow_(row), options: parseJsonArray_(row.optionsJson) }))
  };
}

function saveLesson_(body, auth) {
  requireClearance_(auth, 4);
  const now = new Date().toISOString();
  const id = String(body.id || "");
  const existing = id ? findRow_("Lessons", row => String(row.id) === id) : null;
  const changes = {
    order: Number(body.order || 0),
    title: requiredText_(body.title, "Title", 180),
    description: limitText_(body.description, 1600),
    published: toBoolean_(body.published),
    prerequisiteId: String(body.prerequisiteId || ""),
    mentorUnlockRequired: toBoolean_(body.mentorUnlockRequired),
    passingScore: clampNumber_(body.passingScore || 80, 0, 100),
    updatedAt: now,
    updatedBy: auth.user.id
  };
  let lesson;

  if (existing) {
    if (changes.prerequisiteId === id) throw new ApiError("INVALID_PREREQUISITE", "A lesson cannot require itself.");
    updateObjectByRow_("Lessons", existing.__row, changes);
    lesson = findRow_("Lessons", row => String(row.id) === id);
  } else {
    lesson = { id: Utilities.getUuid(), ...changes, createdAt: now };
    appendObject_("Lessons", lesson);
  }

  addAudit_(auth.user.id, existing ? "lesson_updated" : "lesson_created", "lesson", lesson.id, lesson.title);
  return { lesson: cleanRow_(lesson) };
}

function deleteLesson_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Lesson");
  deleteRowsWhere_("QuizQuestions", question => readRows_("Quizzes").some(quiz => String(quiz.id) === String(question.quizId) && String(quiz.lessonId) === id));
  deleteRowsWhere_("Quizzes", row => String(row.lessonId) === id);
  deleteRowsWhere_("LessonPages", row => String(row.lessonId) === id);
  deleteRowById_("Lessons", id);
  addAudit_(auth.user.id, "lesson_deleted", "lesson", id, "");
  return {};
}

function saveLessonPage_(body, auth) {
  requireClearance_(auth, 4);
  const lessonId = requireId_(body.lessonId, "Lesson");
  if (!findRow_("Lessons", row => String(row.id) === lessonId)) throw new ApiError("LESSON_NOT_FOUND", "Lesson not found.");

  const now = new Date().toISOString();
  const id = String(body.id || "");
  const existing = id ? findRow_("LessonPages", row => String(row.id) === id) : null;
  const changes = {
    lessonId,
    order: Number(body.order || 0),
    title: requiredText_(body.title, "Title", 180),
    body: limitText_(body.body, 30000),
    updatedAt: now,
    updatedBy: auth.user.id
  };
  let page;

  if (existing) {
    updateObjectByRow_("LessonPages", existing.__row, changes);
    page = findRow_("LessonPages", row => String(row.id) === id);
  } else {
    page = { id: Utilities.getUuid(), ...changes, createdAt: now };
    appendObject_("LessonPages", page);
  }

  addAudit_(auth.user.id, existing ? "lesson_page_updated" : "lesson_page_created", "lesson_page", page.id, page.title);
  return { page: cleanRow_(page) };
}

function deleteLessonPage_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Page");
  deleteRowById_("LessonPages", id);
  addAudit_(auth.user.id, "lesson_page_deleted", "lesson_page", id, "");
  return {};
}

function saveQuiz_(body, auth) {
  requireClearance_(auth, 4);
  const lessonId = requireId_(body.lessonId, "Lesson");
  if (!findRow_("Lessons", row => String(row.id) === lessonId)) throw new ApiError("LESSON_NOT_FOUND", "Lesson not found.");

  const kind = ["check", "final"].includes(String(body.kind)) ? String(body.kind) : "check";
  const now = new Date().toISOString();
  const id = String(body.id || "");
  const existing = id ? findRow_("Quizzes", row => String(row.id) === id) : null;
  const changes = {
    lessonId,
    pageId: String(body.pageId || ""),
    order: Number(body.order || 0),
    title: requiredText_(body.title, "Title", 180),
    kind,
    passingScore: clampNumber_(body.passingScore || 80, 0, 100),
    mentorUnlockRequired: toBoolean_(body.mentorUnlockRequired),
    published: toBoolean_(body.published),
    updatedAt: now,
    updatedBy: auth.user.id
  };
  let quiz;

  if (existing) {
    updateObjectByRow_("Quizzes", existing.__row, changes);
    quiz = findRow_("Quizzes", row => String(row.id) === id);
  } else {
    quiz = { id: Utilities.getUuid(), ...changes, createdAt: now };
    appendObject_("Quizzes", quiz);
  }

  addAudit_(auth.user.id, existing ? "quiz_updated" : "quiz_created", "quiz", quiz.id, quiz.title);
  return { quiz: cleanRow_(quiz) };
}

function deleteQuiz_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Quiz");
  deleteRowsWhere_("QuizQuestions", row => String(row.quizId) === id);
  deleteRowById_("Quizzes", id);
  addAudit_(auth.user.id, "quiz_deleted", "quiz", id, "");
  return {};
}

function saveQuestion_(body, auth) {
  requireClearance_(auth, 4);
  const quizId = requireId_(body.quizId, "Quiz");
  if (!findRow_("Quizzes", row => String(row.id) === quizId)) throw new ApiError("QUIZ_NOT_FOUND", "Quiz not found.");

  const type = String(body.type) === "short_answer" ? "short_answer" : "multiple_choice";
  const options = type === "multiple_choice" ? normalizeOptions_(body.options) : [];
  if (type === "multiple_choice" && options.length < 2) throw new ApiError("OPTIONS_REQUIRED", "Multiple choice questions need at least two answer options.");

  const now = new Date().toISOString();
  const id = String(body.id || "");
  const existing = id ? findRow_("QuizQuestions", row => String(row.id) === id) : null;
  const changes = {
    quizId,
    order: Number(body.order || 0),
    type,
    prompt: requiredText_(body.prompt, "Question", 3000),
    optionsJson: JSON.stringify(options),
    correctAnswer: type === "multiple_choice" ? requiredText_(body.correctAnswer, "Correct answer", 1000) : "",
    points: Math.max(1, Number(body.points || 1)),
    explanation: limitText_(body.explanation, 3000),
    published: toBoolean_(body.published),
    updatedAt: now,
    updatedBy: auth.user.id
  };
  let question;

  if (existing) {
    updateObjectByRow_("QuizQuestions", existing.__row, changes);
    question = findRow_("QuizQuestions", row => String(row.id) === id);
  } else {
    question = { id: Utilities.getUuid(), ...changes, createdAt: now };
    appendObject_("QuizQuestions", question);
  }

  addAudit_(auth.user.id, existing ? "question_updated" : "question_created", "question", question.id, question.prompt.slice(0, 120));
  return { question: cleanRow_(question) };
}

function deleteQuestion_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Question");
  deleteRowById_("QuizQuestions", id);
  addAudit_(auth.user.id, "question_deleted", "question", id, "");
  return {};
}

function listOnboardingAdmin_(auth) {
  requireClearance_(auth, 4);
  return { steps: readRows_("Onboarding").sort(orderSort_).map(cleanRow_) };
}

function saveOnboardingStep_(body, auth) {
  requireClearance_(auth, 4);
  const now = new Date().toISOString();
  const id = String(body.id || "");
  const existing = id ? findRow_("Onboarding", row => String(row.id) === id) : null;
  const changes = {
    order: Number(body.order || 0),
    title: requiredText_(body.title, "Title", 180),
    description: limitText_(body.description, 1600),
    body: limitText_(body.body, 30000),
    required: toBoolean_(body.required),
    published: toBoolean_(body.published),
    updatedAt: now,
    updatedBy: auth.user.id
  };
  let step;

  if (existing) {
    updateObjectByRow_("Onboarding", existing.__row, changes);
    step = findRow_("Onboarding", row => String(row.id) === id);
  } else {
    step = { id: Utilities.getUuid(), ...changes, createdAt: now };
    appendObject_("Onboarding", step);
  }

  addAudit_(auth.user.id, existing ? "onboarding_updated" : "onboarding_created", "onboarding", step.id, step.title);
  return { step: cleanRow_(step) };
}

function deleteOnboardingStep_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Onboarding step");
  deleteRowsWhere_("OnboardingProgress", row => String(row.stepId) === id);
  deleteRowById_("Onboarding", id);
  addAudit_(auth.user.id, "onboarding_deleted", "onboarding", id, "");
  return {};
}

function listRestricted_(body, auth) {
  requireClearance_(auth, 4);
  reauthenticate_(body.password, auth.user);
  const rows = readRows_("RestrictedRecords").sort((a, b) => dateNumber_(b.createdAt) - dateNumber_(a.createdAt)).map(row => ({ ...cleanRow_(row), evidence: parseJsonArray_(row.evidenceJson) }));
  const names = userNameMap_();
  const accessLog = readRows_("RestrictedAccessLog")
    .sort((a, b) => dateNumber_(b.time) - dateNumber_(a.time))
    .slice(0, 500)
    .map(row => ({ ...cleanRow_(row), viewerName: names[String(row.viewerId)] || String(row.viewerId || "Unknown") }));
  addRestrictedAccess_("", auth.user.id, "list");
  addAudit_(auth.user.id, "restricted_list_viewed", "restricted", "", "");
  return { records: rows, accessLog };
}

function getRestricted_(body, auth) {
  requireClearance_(auth, 4);
  reauthenticate_(body.password, auth.user);
  const id = requireId_(body.id, "Restricted record");
  const row = findRow_("RestrictedRecords", item => String(item.id) === id);
  if (!row) throw new ApiError("RECORD_NOT_FOUND", "Restricted record not found.");
  addRestrictedAccess_(id, auth.user.id, "view");
  addAudit_(auth.user.id, "restricted_record_viewed", "restricted", id, "");
  return { record: { ...cleanRow_(row), evidence: parseJsonArray_(row.evidenceJson) } };
}

function saveRestricted_(body, auth) {
  requireClearance_(auth, 4);
  reauthenticate_(body.password, auth.user);
  const now = new Date().toISOString();
  const id = String(body.id || "");
  const existing = id ? findRow_("RestrictedRecords", row => String(row.id) === id) : null;
  const evidence = Array.isArray(body.evidence) ? body.evidence.map(String).filter(Boolean) : [];

  if (existing) {
    const changes = {
      title: requiredText_(body.title, "Title", 180),
      status: limitText_(body.status, 80),
      description: limitText_(body.description, 10000),
      evidenceJson: evidence.length ? JSON.stringify(evidence) : String(existing.evidenceJson || "[]"),
      extraNotes: limitText_(body.extraNotes, 10000),
      updatedAt: now,
      updatedBy: auth.user.id
    };
    updateObjectByRow_("RestrictedRecords", existing.__row, changes);
    addAudit_(auth.user.id, "restricted_record_updated", "restricted", existing.id, "");
    return { record: { ...cleanRow_(findRow_("RestrictedRecords", row => String(row.id) === id)), evidence: parseJsonArray_(evidence.length ? JSON.stringify(evidence) : existing.evidenceJson) } };
  }

  const immutableUserId = requiredText_(body.userId, "User ID", 300);
  const record = {
    id: Utilities.getUuid(),
    title: requiredText_(body.title, "Title", 180),
    userId: immutableUserId,
    status: limitText_(body.status, 80),
    description: limitText_(body.description, 10000),
    evidenceJson: JSON.stringify(evidence),
    extraNotes: limitText_(body.extraNotes, 10000),
    createdAt: now,
    updatedAt: now,
    createdBy: auth.user.id,
    updatedBy: auth.user.id
  };
  appendObject_("RestrictedRecords", record);
  addAudit_(auth.user.id, "restricted_record_created", "restricted", record.id, immutableUserId);
  return { record: { ...cleanRow_(record), evidence } };
}

function uploadRestrictedEvidence_(body, auth) {
  requireClearance_(auth, 4);
  reauthenticate_(body.password, auth.user);
  const upload = saveUpload_(body, auth.user.id, "restricted_evidence");
  addAudit_(auth.user.id, "restricted_evidence_uploaded", "upload", upload.id, upload.name);
  return { upload: cleanRow_(upload) };
}

function getRestrictedEvidence_(body, auth) {
  requireClearance_(auth, 4);
  reauthenticate_(body.password, auth.user);
  const uploadId = requireId_(body.uploadId, "Evidence");
  const upload = findRow_("Uploads", row => String(row.id) === uploadId && String(row.category) === "restricted_evidence");
  if (!upload) throw new ApiError("UPLOAD_NOT_FOUND", "Evidence file not found.");
  addRestrictedAccess_(String(body.recordId || ""), auth.user.id, "evidence");
  addAudit_(auth.user.id, "restricted_evidence_viewed", "upload", uploadId, "");
  return { name: upload.name, mimeType: upload.mimeType, dataUrl: uploadDataUrl_(upload) };
}

function listAudit_(auth) {
  requireClearance_(auth, 4);
  const users = userNameMap_();
  const entries = readRows_("Audit")
    .sort((a, b) => dateNumber_(b.time) - dateNumber_(a.time))
    .slice(0, 1000)
    .map(row => ({ ...cleanRow_(row), userName: users[String(row.userId)] || String(row.userId || "System") }));
  return { entries };
}

function listAnnouncements_(auth) {
  const rows = readRows_("Announcements")
    .filter(row => Number(auth.user.clearance) >= 5 || toBoolean_(row.published))
    .sort((a, b) => Number(toBoolean_(b.pinned)) - Number(toBoolean_(a.pinned)) || dateNumber_(b.updatedAt || b.createdAt) - dateNumber_(a.updatedAt || a.createdAt))
    .map(cleanRow_);
  return { announcements: rows };
}

function saveAnnouncement_(body, auth) {
  requireClearance_(auth, 5);
  const id = String(body.id || "");
  const existing = id ? findRow_("Announcements", row => String(row.id) === id) : null;
  const now = new Date().toISOString();
  const changes = {
    title: requiredText_(body.title, "Title", 180),
    description: limitText_(body.description, 5000),
    pinned: toBoolean_(body.pinned),
    published: toBoolean_(body.published),
    updatedAt: now,
    updatedBy: auth.user.id
  };
  let row;

  if (existing) {
    updateObjectByRow_("Announcements", existing.__row, changes);
    row = findRow_("Announcements", item => String(item.id) === id);
  } else {
    row = { id: Utilities.getUuid(), ...changes, createdAt: now, createdBy: auth.user.id };
    appendObject_("Announcements", row);
  }

  if (toBoolean_(row.published)) notifyAllActive_(row.title, row.description.slice(0, 240), "announcement", auth.user.id);
  addAudit_(auth.user.id, existing ? "announcement_updated" : "announcement_created", "announcement", row.id, row.title);
  return { announcement: cleanRow_(row) };
}

function deleteAnnouncement_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Announcement");
  deleteRowById_("Announcements", id);
  addAudit_(auth.user.id, "announcement_deleted", "announcement", id, "");
  return {};
}

function listHelp_(auth) {
  const rows = readRows_("Help")
    .filter(row => Number(auth.user.clearance) >= 5 || toBoolean_(row.published))
    .sort((a, b) => String(a.title).localeCompare(String(b.title)))
    .map(cleanRow_);
  return { help: rows };
}

function saveHelp_(body, auth) {
  requireClearance_(auth, 5);
  const id = String(body.id || "");
  const existing = id ? findRow_("Help", row => String(row.id) === id) : null;
  const now = new Date().toISOString();
  const changes = {
    title: requiredText_(body.title, "Title", 180),
    description: limitText_(body.description, 1600),
    body: limitText_(body.body, 30000),
    published: toBoolean_(body.published),
    updatedAt: now,
    updatedBy: auth.user.id
  };
  let row;

  if (existing) {
    updateObjectByRow_("Help", existing.__row, changes);
    row = findRow_("Help", item => String(item.id) === id);
  } else {
    row = { id: Utilities.getUuid(), ...changes, createdAt: now };
    appendObject_("Help", row);
  }

  addAudit_(auth.user.id, existing ? "help_updated" : "help_created", "help", row.id, row.title);
  return { help: cleanRow_(row) };
}

function deleteHelp_(body, auth) {
  requireClearance_(auth, 5);
  const id = requireId_(body.id, "Help entry");
  deleteRowById_("Help", id);
  addAudit_(auth.user.id, "help_deleted", "help", id, "");
  return {};
}

function getUserSettings_(auth) {
  return { settings: cleanRow_(getUserSettingsRow_(auth.user.id)) };
}

function saveUserSettings_(body, auth) {
  const allowedThemes = ["light", "dark"];
  const allowedDensity = ["comfortable", "compact"];
  const changes = {
    theme: allowedThemes.includes(String(body.theme)) ? String(body.theme) : "light",
    density: allowedDensity.includes(String(body.density)) ? String(body.density) : "comfortable",
    sidebarCollapsed: toBoolean_(body.sidebarCollapsed),
    reducedMotion: toBoolean_(body.reducedMotion),
    highContrast: toBoolean_(body.highContrast),
    portalNotifications: body.portalNotifications === undefined ? true : toBoolean_(body.portalNotifications),
    messageNotifications: body.messageNotifications === undefined ? true : toBoolean_(body.messageNotifications),
    updatedAt: new Date().toISOString()
  };

  let row = findRow_("UserSettings", item => String(item.userId) === String(auth.user.id));
  if (row) {
    updateObjectByRow_("UserSettings", row.__row, changes);
    row = findRow_("UserSettings", item => String(item.userId) === String(auth.user.id));
  } else {
    row = { userId: auth.user.id, ...changes };
    appendObject_("UserSettings", row);
  }

  return { settings: cleanRow_(row) };
}

function getContent_(auth) {
  requireClearance_(auth, 5);
  return { content: readRows_("Content").sort((a, b) => String(a.key).localeCompare(String(b.key))).map(cleanRow_) };
}

function saveContent_(body, auth) {
  requireClearance_(auth, 5);
  const key = requiredText_(body.key, "Content key", 200);
  const value = limitText_(body.value, 10000);
  const now = new Date().toISOString();
  let row = findRow_("Content", item => String(item.key) === key);

  if (row) updateObjectByRow_("Content", row.__row, { value, updatedAt: now, updatedBy: auth.user.id });
  else appendObject_("Content", { key, value, updatedAt: now, updatedBy: auth.user.id });

  addAudit_(auth.user.id, "portal_content_updated", "content", key, "");
  return { key, value };
}

function getAdminStats_(auth) {
  requireClearance_(auth, 5);
  return {
    stats: {
      users: readRows_("Users").length,
      activeUsers: readRows_("Users").filter(row => String(row.status) === "active").length,
      activeSessions: readRows_("Sessions").filter(row => !toBoolean_(row.revoked) && dateNumber_(row.expiresAt) > Date.now()).length,
      lessons: readRows_("Lessons").length,
      quizzes: readRows_("Quizzes").length,
      restrictedRecords: readRows_("RestrictedRecords").length,
      maintenance: getSettingValue_("maintenance.enabled", "false") === "true"
    },
    maintenanceMessage: getSettingValue_("maintenance.message", "")
  };
}

function setMaintenance_(body, auth) {
  requireClearance_(auth, 5);
  setSettingValue_("maintenance.enabled", toBoolean_(body.enabled) ? "true" : "false", auth.user.id);
  setSettingValue_("maintenance.message", limitText_(body.message, 1000), auth.user.id);
  addAudit_(auth.user.id, "maintenance_updated", "settings", "maintenance", String(toBoolean_(body.enabled)));
  return { enabled: toBoolean_(body.enabled) };
}

function cleanupSessionsAction_(auth) {
  requireClearance_(auth, 5);
  const count = cleanupExpiredSessions_();
  addAudit_(auth.user.id, "sessions_cleaned", "sessions", "", String(count));
  return { cleaned: count };
}

function backupDatabase_(auth) {
  requireClearance_(auth, 5);
  const id = PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");
  const file = DriveApp.getFileById(id);
  const stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "UTC", "yyyy-MM-dd HHmmss");
  const copy = file.makeCopy(`Mod Portal Backup ${stamp}`);
  addAudit_(auth.user.id, "database_backup_created", "backup", copy.getId(), copy.getName());
  return { backupId: copy.getId(), name: copy.getName() };
}

function lessonAccess_(user, lesson, progressByLesson) {
  if (Number(user.clearance) >= 2) return { allowed: true, reason: "" };
  if (!toBoolean_(lesson.published)) return { allowed: false, reason: "This lesson is not published." };

  const prerequisiteId = String(lesson.prerequisiteId || "");
  if (prerequisiteId) {
    const prerequisite = progressByLesson[prerequisiteId];
    if (!prerequisite || String(prerequisite.status) !== "completed") return { allowed: false, reason: "Complete the prerequisite lesson first." };
  }

  if (toBoolean_(lesson.mentorUnlockRequired)) {
    const progress = progressByLesson[String(lesson.id)];
    if (!progress || !toBoolean_(progress.mentorUnlock)) return { allowed: false, reason: "This lesson must be unlocked by your mentor." };
  }

  return { allowed: true, reason: "" };
}

function defaultProgress_(userId, lessonId) {
  return { userId, lessonId, status: "not_started", progress: 0, currentPageId: "", mentorUnlock: false, finalQuizUnlocked: false, score: "", startedAt: "", completedAt: "", updatedAt: "" };
}

function findProgress_(userId, lessonId) {
  return findRow_("TrainingProgress", row => String(row.userId) === String(userId) && String(row.lessonId) === String(lessonId));
}

function upsertProgress_(userId, lessonId, changes) {
  let row = findProgress_(userId, lessonId);
  if (row) {
    updateObjectByRow_("TrainingProgress", row.__row, changes);
    return findProgress_(userId, lessonId);
  }
  row = { ...defaultProgress_(userId, lessonId), ...changes };
  appendObject_("TrainingProgress", row);
  return row;
}

function completeLesson_(userId, lessonId, score) {
  const now = new Date().toISOString();
  upsertProgress_(userId, lessonId, { status: "completed", progress: 100, score, completedAt: now, updatedAt: now });
  addNotification_(userId, "Lesson completed", "You passed the final quiz and completed the lesson.", "training");
}

function upsertGrade_(attempt, title) {
  let grade = findRow_("Grades", row => String(row.userId) === String(attempt.userId) && String(row.quizId) === String(attempt.quizId) && String(row.id) === String(attempt.id));
  const changes = {
    userId: attempt.userId,
    lessonId: attempt.lessonId,
    quizId: attempt.quizId,
    title: String(title || "Quiz"),
    status: attempt.status,
    score: attempt.score,
    reviewerId: attempt.reviewerId,
    feedback: attempt.feedback,
    updatedAt: attempt.gradedAt || attempt.submittedAt
  };

  if (grade) updateObjectByRow_("Grades", grade.__row, changes);
  else appendObject_("Grades", { id: attempt.id, ...changes, createdAt: attempt.submittedAt });
}

function attemptDetail_(attempt) {
  const user = findUserById_(attempt.userId);
  const quiz = findRow_("Quizzes", row => String(row.id) === String(attempt.quizId));
  const questions = quiz ? readRows_("QuizQuestions").filter(row => String(row.quizId) === String(quiz.id)).map(row => ({ id: row.id, prompt: row.prompt, type: row.type, points: Number(row.points || 1) })) : [];
  return {
    ...cleanRow_(attempt),
    userName: user ? user.displayName : "Unknown",
    username: user ? user.username : "",
    quizTitle: quiz ? quiz.title : "Quiz",
    passingScore: quiz ? Number(quiz.passingScore || 80) : 80,
    answers: parseJsonArray_(attempt.answersJson),
    questions
  };
}

function mentorCadets_(auth) {
  const users = readRows_("Users").filter(row => Number(row.clearance) === 1 && String(row.status) === "active");
  if (Number(auth.user.clearance) >= 4) return users;
  return users.filter(row => String(row.mentorId) === String(auth.user.id));
}

function assertMentorControlsUser_(auth, userId) {
  if (Number(auth.user.clearance) >= 4) return true;
  const user = findUserById_(userId);
  if (!user || String(user.mentorId) !== String(auth.user.id)) throw new ApiError("FORBIDDEN", "You are not assigned to this cadet.");
  return true;
}

function notifyMentorForSubmission_(user, attempt, quiz) {
  if (user.mentorId) addNotification_(user.mentorId, "Submission awaiting review", `${user.displayName} submitted ${quiz.title}.`, "grade");
  notifyClearance_(4, "Submission awaiting review", `${user.displayName} submitted ${quiz.title}.`, "grade", user.mentorId ? [String(user.mentorId)] : []);
}

function updateOnboardingCompletion_(userId) {
  const required = readRows_("Onboarding").filter(row => toBoolean_(row.published) && toBoolean_(row.required));
  const completed = new Set(readRows_("OnboardingProgress").filter(row => String(row.userId) === String(userId) && toBoolean_(row.completed)).map(row => String(row.stepId)));
  const done = required.every(step => completed.has(String(step.id)));
  const user = findUserById_(userId);
  if (user) updateObjectByRow_("Users", user.__row, { onboardingComplete: done });
  return done;
}

function questionPublic_(question) {
  return {
    id: String(question.id),
    quizId: String(question.quizId),
    order: Number(question.order || 0),
    type: String(question.type || "multiple_choice"),
    prompt: String(question.prompt || ""),
    options: parseJsonArray_(question.optionsJson),
    points: Number(question.points || 1),
    published: toBoolean_(question.published)
  };
}

function addNotification_(userId, title, description, type) {
  appendObject_("Notifications", {
    id: Utilities.getUuid(), userId: String(userId), title: String(title || ""), description: String(description || ""), type: String(type || "general"), read: false, createdAt: new Date().toISOString()
  });
}

function notifyClearance_(minimum, title, description, type, excludedIds) {
  const excluded = new Set((excludedIds || []).map(String));
  readRows_("Users")
    .filter(row => String(row.status) === "active" && Number(row.clearance) >= Number(minimum) && !excluded.has(String(row.id)))
    .forEach(row => addNotification_(row.id, title, description, type));
}

function notifyAllActive_(title, description, type, excludedId) {
  readRows_("Users")
    .filter(row => String(row.status) === "active" && String(row.id) !== String(excludedId || ""))
    .forEach(row => addNotification_(row.id, title, description, type));
}

function addRestrictedAccess_(recordId, viewerId, action) {
  appendObject_("RestrictedAccessLog", { id: Utilities.getUuid(), recordId: String(recordId || ""), viewerId: String(viewerId), action: String(action), time: new Date().toISOString() });
}

function reauthenticate_(password, user) {
  const verification = verifyPassword_(String(password || ""), String(user.passwordSalt), String(user.passwordHash));
  if (!verification.valid) throw new ApiError("REAUTH_FAILED", "Password verification failed.");
}

function saveUpload_(body, ownerId, category) {
  const name = sanitizeFileName_(body.name || "upload");
  const mimeType = String(body.mimeType || "application/octet-stream");
  const base64 = String(body.base64 || "");
  if (!base64) throw new ApiError("FILE_REQUIRED", "Choose a file first.");

  let bytes;
  try { bytes = Utilities.base64Decode(base64); }
  catch { throw new ApiError("INVALID_FILE", "The uploaded file could not be decoded."); }

  if (bytes.length > MAX_UPLOAD_BYTES) throw new ApiError("FILE_TOO_LARGE", "Files must be 5 MB or smaller.");

  const folder = getUploadFolder_();
  const blob = Utilities.newBlob(bytes, mimeType, name);
  const file = folder.createFile(blob);
  const row = { id: Utilities.getUuid(), driveFileId: file.getId(), ownerId: String(ownerId), category: String(category), name, mimeType, createdAt: new Date().toISOString() };
  appendObject_("Uploads", row);
  return row;
}

function uploadDataUrl_(upload) {
  const file = DriveApp.getFileById(String(upload.driveFileId));
  const blob = file.getBlob();
  const encoded = Utilities.base64Encode(blob.getBytes());
  return `data:${upload.mimeType || blob.getContentType()};base64,${encoded}`;
}

function getUploadFolder_() {
  const props = PropertiesService.getScriptProperties();
  const existingId = props.getProperty("UPLOAD_FOLDER_ID");
  if (existingId) {
    try { return DriveApp.getFolderById(existingId); }
    catch {}
  }
  const folder = DriveApp.createFolder("Mod Portal Uploads");
  props.setProperty("UPLOAD_FOLDER_ID", folder.getId());
  return folder;
}

function getUserSettingsRow_(userId) {
  return findRow_("UserSettings", row => String(row.userId) === String(userId)) || {
    userId, theme: "light", density: "comfortable", sidebarCollapsed: false, reducedMotion: false, highContrast: false, portalNotifications: true, messageNotifications: true, updatedAt: ""
  };
}

function seedContent_() {
  const existing = new Set(readRows_("Content").map(row => String(row.key)));
  const now = new Date().toISOString();
  Object.entries(DEFAULT_CONTENT).forEach(([key, value]) => {
    if (!existing.has(key)) appendObject_("Content", { key, value, updatedAt: now, updatedBy: "system" });
  });
}

function getSettingValue_(key, fallback) {
  const row = findRow_("Settings", item => String(item.key) === String(key));
  return row ? String(row.value || "") : fallback;
}

function setSettingValue_(key, value, userId) {
  const row = findRow_("Settings", item => String(item.key) === String(key));
  const now = new Date().toISOString();
  if (row) updateObjectByRow_("Settings", row.__row, { value: String(value), updatedAt: now, updatedBy: userId });
  else appendObject_("Settings", { key: String(key), value: String(value), updatedAt: now, updatedBy: userId });
}

function requireSession_(token) {
  const rawToken = String(token || "");
  if (!rawToken) throw new ApiError("AUTH_REQUIRED", "Sign in required.");

  const tokenHash = sessionTokenHash_(rawToken);
  const session = findRow_("Sessions", row => String(row.tokenHash) === tokenHash);
  if (!session || toBoolean_(session.revoked)) throw new ApiError("INVALID_SESSION", "Session is invalid.");

  const expiresAt = dateNumber_(session.expiresAt);
  if (!expiresAt || Date.now() >= expiresAt) {
    updateObjectByRow_("Sessions", session.__row, { revoked: true });
    throw new ApiError("SESSION_EXPIRED", "Session expired.");
  }

  const user = findUserById_(session.userId);
  if (!user) throw new ApiError("INVALID_SESSION", "Session is invalid.");

  const status = String(user.status || "").toLowerCase();
  if (status === "suspended") throw new ApiError("ACCOUNT_SUSPENDED", "This account is suspended.");
  if (status !== "active") throw new ApiError("ACCOUNT_INACTIVE", "Account is not active.");

  const maintenance = getSettingValue_("maintenance.enabled", "false") === "true";
  if (maintenance && Number(user.clearance) < 5) throw new ApiError("MAINTENANCE", getSettingValue_("maintenance.message", "The portal is temporarily unavailable."));

  updateObjectByRow_("Sessions", session.__row, { lastSeenAt: new Date().toISOString() });
  return { user, session };
}

function createSession_(userId) {
  const rawToken = `${Utilities.getUuid()}${Utilities.getUuid()}${Utilities.getUuid()}`;
  const created = new Date();
  const expires = new Date(created.getTime() + SESSION_HOURS * 60 * 60 * 1000);
  const session = {
    id: Utilities.getUuid(), userId: String(userId), tokenHash: sessionTokenHash_(rawToken), createdAt: created.toISOString(), expiresAt: expires.toISOString(), revoked: false, lastSeenAt: created.toISOString()
  };
  appendObject_("Sessions", session);
  return { token: rawToken, expiresAt: session.expiresAt };
}

function revokeUserSessions_(userId) {
  readRows_("Sessions")
    .filter(row => String(row.userId) === String(userId) && !toBoolean_(row.revoked))
    .forEach(row => updateObjectByRow_("Sessions", row.__row, { revoked: true }));
}

function cleanupExpiredSessions_() {
  const rows = readRows_("Sessions");
  let count = 0;
  rows.forEach(row => {
    if (!toBoolean_(row.revoked) && dateNumber_(row.expiresAt) <= Date.now()) {
      updateObjectByRow_("Sessions", row.__row, { revoked: true });
      count++;
    }
  });
  return count;
}

function requireClearance_(auth, minimum) {
  if (Number(auth.user.clearance) < Number(minimum)) throw new ApiError("FORBIDDEN", "You do not have permission to do that.");
}

function findUserByUsername_(username) {
  const normalized = normalizeUsername_(username);
  return findRow_("Users", row => normalizeUsername_(row.username) === normalized);
}

function findUserById_(id) {
  return findRow_("Users", row => String(row.id) === String(id));
}

function findUserTarget_(body) {
  if (body.userId) return findUserById_(body.userId);
  if (body.username) return findUserByUsername_(body.username);
  return null;
}

function publicUser_(user) {
  return {
    id: String(user.id || ""), username: String(user.username || ""), displayName: String(user.displayName || user.username || "Portal User"),
    role: String(user.role || roleForClearance_(user.clearance)), clearance: Number(user.clearance || 1), status: String(user.status || "active"),
    mentorId: String(user.mentorId || ""), forcePasswordReset: toBoolean_(user.forcePasswordReset), description: String(user.description || ""),
    onboardingComplete: toBoolean_(user.onboardingComplete), lastLogin: String(user.lastLogin || "")
  };
}

function profileUser_(user) {
  return {
    ...publicUser_(user), pronouns: String(user.pronouns || ""), roleTitle: String(user.roleTitle || ""), timezone: String(user.timezone || ""),
    bio: String(user.bio || ""), askMeAbout: String(user.askMeAbout || ""), availability: String(user.availability || ""), accentColor: String(user.accentColor || ""),
    hasAvatar: Boolean(user.avatarFileId), createdAt: String(user.createdAt || "")
  };
}

function adminUser_(user) {
  return { ...profileUser_(user), mentorName: user.mentorId ? String(findUserById_(user.mentorId)?.displayName || "") : "" };
}

function userNameMap_() {
  const map = {};
  readRows_("Users").forEach(row => map[String(row.id)] = String(row.displayName || row.username || "Unknown"));
  return map;
}

function roleForClearance_(clearance) {
  return ({ 5: "Owner", 4: "Supervisor", 3: "Senior", 2: "Officer", 1: "Cadet" })[Number(clearance)] || "Cadet";
}

function validateUsername_(value) {
  const username = String(value || "").trim();
  if (username.length < 3 || username.length > 40) throw new ApiError("INVALID_USERNAME", "Username must be 3 to 40 characters.");
  if (!/^[A-Za-z0-9._-]+$/.test(username)) throw new ApiError("INVALID_USERNAME", "Username can only use letters, numbers, periods, underscores, and hyphens.");
}

function validatePassword_(value) {
  const password = String(value || "");
  if (password.length < 10) throw new ApiError("WEAK_PASSWORD", "Password must be at least 10 characters.");
}

function passwordHash_(password, salt) {
  const pepper = PropertiesService.getScriptProperties().getProperty("PASSWORD_PEPPER");
  if (!pepper) throw new Error("Password secret is missing.");

  let value = `${salt}:${password}`;
  for (let i = 0; i < 2500; i++) {
    const bytes = Utilities.computeHmacSha256Signature(value, pepper, Utilities.Charset.UTF_8);
    value = Utilities.base64EncodeWebSafe(bytes);
  }
  return value;
}

function legacyPasswordHash_(password, salt) {
  const pepper = PropertiesService.getScriptProperties().getProperty("PASSWORD_PEPPER");
  if (!pepper) throw new Error("Password secret is missing.");
  const bytes = Utilities.computeHmacSha256Signature(`${salt}:${password}`, pepper, Utilities.Charset.UTF_8);
  return Utilities.base64EncodeWebSafe(bytes);
}

function verifyPassword_(password, salt, storedHash) {
  const currentHash = passwordHash_(password, salt);
  if (safeEquals_(currentHash, storedHash)) return { valid: true, legacy: false, currentHash };
  const legacyHash = legacyPasswordHash_(password, salt);
  const valid = safeEquals_(legacyHash, storedHash);
  return { valid, legacy: valid, currentHash };
}

function sessionTokenHash_(token) {
  const secret = PropertiesService.getScriptProperties().getProperty("SESSION_SECRET");
  if (!secret) throw new Error("Session secret is missing.");
  const bytes = Utilities.computeHmacSha256Signature(token, secret, Utilities.Charset.UTF_8);
  return Utilities.base64EncodeWebSafe(bytes);
}

function createSalt_() {
  return Utilities.getUuid();
}

function createSecret_() {
  const source = `${Utilities.getUuid()}${Utilities.getUuid()}${Utilities.getUuid()}${Date.now()}`;
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, source, Utilities.Charset.UTF_8);
  return Utilities.base64EncodeWebSafe(bytes);
}

function safeEquals_(a, b) {
  const left = String(a);
  const right = String(b);
  let difference = left.length ^ right.length;
  const length = Math.max(left.length, right.length);
  for (let i = 0; i < length; i++) difference |= (left.charCodeAt(i) || 0) ^ (right.charCodeAt(i) || 0);
  return difference === 0;
}

function normalizeUsername_(value) {
  return String(value || "").trim().toLowerCase();
}

function normalizeAnswer_(value) {
  return String(value || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function rateKey_(username) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, normalizeUsername_(username), Utilities.Charset.UTF_8);
  return `LOGIN_ATTEMPT_${Utilities.base64EncodeWebSafe(bytes)}`;
}

function isRateLimited_(username) {
  const props = PropertiesService.getScriptProperties();
  const key = rateKey_(username);
  const value = props.getProperty(key);
  if (!value) return false;

  try {
    const record = JSON.parse(value);
    const windowMs = LOGIN_WINDOW_MINUTES * 60 * 1000;
    if (Date.now() - Number(record.startedAt) > windowMs) {
      props.deleteProperty(key);
      return false;
    }
    return Number(record.count) >= LOGIN_MAX_FAILURES;
  } catch {
    props.deleteProperty(key);
    return false;
  }
}

function recordLoginFailure_(username) {
  const props = PropertiesService.getScriptProperties();
  const key = rateKey_(username);
  let record = { count: 0, startedAt: Date.now() };
  const value = props.getProperty(key);

  if (value) {
    try { record = JSON.parse(value); }
    catch {}
  }

  const windowMs = LOGIN_WINDOW_MINUTES * 60 * 1000;
  if (Date.now() - Number(record.startedAt) > windowMs) record = { count: 0, startedAt: Date.now() };
  record.count = Number(record.count || 0) + 1;
  props.setProperty(key, JSON.stringify(record));
}

function clearLoginFailures_(username) {
  PropertiesService.getScriptProperties().deleteProperty(rateKey_(username));
}

function generateTemporaryPassword_() {
  const source = `${Utilities.getUuid()}${Utilities.getUuid()}`.replace(/-/g, "");
  return `${source.slice(0, 8)}!${source.slice(8, 18)}Aa7`;
}

function ensureSheet_(spreadsheet, name, headers) {
  let sheet = spreadsheet.getSheetByName(name);
  if (!sheet) sheet = spreadsheet.insertSheet(name);

  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return;
  }

  const existingHeaders = getHeaders_(sheet);
  const missing = headers.filter(header => !existingHeaders.includes(header));
  if (missing.length) sheet.getRange(1, existingHeaders.length + 1, 1, missing.length).setValues([missing]);
  sheet.setFrozenRows(1);
}

function syncUserSchema_() {
  const sheet = getSheet_("Users");
  const allowed = new Set(TABLES.Users);
  const headers = getHeaders_(sheet);
  const remove = [];

  headers.forEach((header, index) => {
    if (!allowed.has(header)) remove.push(index + 1);
  });

  remove.sort((a, b) => b - a).forEach(column => sheet.deleteColumn(column));
}

function getDatabase_() {
  const id = PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");
  if (!id) throw new Error("Database has not been initialized.");
  return SpreadsheetApp.openById(id);
}

function getSheet_(name) {
  const sheet = getDatabase_().getSheetByName(name);
  if (!sheet) throw new Error(`Missing sheet: ${name}`);
  return sheet;
}

function getHeaders_(sheet) {
  if (sheet.getLastColumn() === 0) return [];
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(value => String(value).trim());
}

function readRows_(sheetName) {
  const sheet = getSheet_(sheetName);
  const lastRow = sheet.getLastRow();
  const lastColumn = sheet.getLastColumn();
  if (lastRow < 2 || lastColumn < 1) return [];

  const headers = getHeaders_(sheet);
  const values = sheet.getRange(2, 1, lastRow - 1, lastColumn).getValues();
  return values.map((row, index) => {
    const object = { __row: index + 2 };
    headers.forEach((header, column) => object[header] = row[column]);
    return object;
  });
}

function findRow_(sheetName, predicate) {
  return readRows_(sheetName).find(predicate) || null;
}

function appendObject_(sheetName, object) {
  const sheet = getSheet_(sheetName);
  const headers = getHeaders_(sheet);
  sheet.appendRow(headers.map(header => object[header] ?? ""));
}

function updateObjectByRow_(sheetName, rowNumber, changes) {
  const sheet = getSheet_(sheetName);
  const headers = getHeaders_(sheet);
  const row = sheet.getRange(rowNumber, 1, 1, headers.length).getValues()[0];
  Object.entries(changes).forEach(([key, value]) => {
    const index = headers.indexOf(key);
    if (index !== -1) row[index] = value;
  });
  sheet.getRange(rowNumber, 1, 1, headers.length).setValues([row]);
}

function deleteRowById_(sheetName, id) {
  const row = findRow_(sheetName, item => String(item.id) === String(id));
  if (!row) throw new ApiError("NOT_FOUND", "Item not found.");
  getSheet_(sheetName).deleteRow(row.__row);
}

function deleteRowsWhere_(sheetName, predicate) {
  const sheet = getSheet_(sheetName);
  readRows_(sheetName).filter(predicate).sort((a, b) => b.__row - a.__row).forEach(row => sheet.deleteRow(row.__row));
}

function addAudit_(userId, action, targetType, targetId, details) {
  appendObject_("Audit", {
    id: Utilities.getUuid(), time: new Date().toISOString(), userId: String(userId || ""), action: String(action || ""), targetType: String(targetType || ""), targetId: String(targetId || ""), details: String(details || "")
  });
}

function withLock_(callback) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try { return callback(); }
  finally { lock.releaseLock(); }
}

function parseBody_(e) {
  const contents = e && e.postData && e.postData.contents ? e.postData.contents : "{}";
  try { return JSON.parse(contents); }
  catch { throw new ApiError("INVALID_JSON", "Invalid request."); }
}

function jsonResponse_(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}

function cleanRow_(row) {
  if (!row) return null;
  const copy = {};
  Object.keys(row).forEach(key => {
    if (!key.startsWith("__")) copy[key] = row[key];
  });
  return copy;
}

function toBoolean_(value) {
  if (value === true || value === 1) return true;
  return String(value || "").toLowerCase() === "true";
}

function dateNumber_(value) {
  const n = new Date(String(value || "")).getTime();
  return Number.isFinite(n) ? n : 0;
}

function clampNumber_(value, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return min;
  return Math.min(max, Math.max(min, number));
}

function requiredText_(value, label, max) {
  const text = limitText_(value, max);
  if (!text) throw new ApiError("FIELD_REQUIRED", `${label} is required.`);
  return text;
}

function limitText_(value, max) {
  return String(value == null ? "" : value).trim().slice(0, max);
}

function requireId_(value, label) {
  const id = String(value || "").trim();
  if (!id) throw new ApiError("ID_REQUIRED", `${label} ID is required.`);
  return id;
}

function parseJsonArray_(value) {
  try {
    const parsed = JSON.parse(String(value || "[]"));
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}

function normalizeOptions_(value) {
  if (Array.isArray(value)) return value.map(item => String(item).trim()).filter(Boolean).slice(0, 12);
  return String(value || "").split(/\r?\n/).map(item => item.trim()).filter(Boolean).slice(0, 12);
}

function orderSort_(a, b) {
  return Number(a.order || 0) - Number(b.order || 0);
}

function sanitizeFileName_(value) {
  const cleaned = String(value || "upload").replace(/[\\/:*?"<>|]/g, "_").slice(0, 180);
  return cleaned || "upload";
}

function existingOrNow_(value) {
  return value ? String(value) : new Date().toISOString();
}
